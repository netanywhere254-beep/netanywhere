# Net.Anywhere Website

Professional marketing site for **net.anywhere** – Kenyan Wi-Fi hotspot & PPPoE broadband provider.

## Files

| File | Purpose |
|------|---------|
| `index.html` | Main page structure & content |
| `styles.css` | All styling (colours, layout, responsive) |
| `script.js` | Modals, forms, estimator, chatbot |

## How to edit content

### Change phone / email / social
Search for these strings in `index.html` and `script.js`:
- `0115 503 175`
- `netanywhere254@gmail.com`
- `@net.anywhere`

### Change hotspot package prices
In `index.html` find the section `id="packages"`.  
Each package card has:
- Duration text
- Price (`Ksh <strong>XX</strong>`)
- `data-package` and `data-price` attributes on the button

### Change PPPoE / Home Fiber prices
In the section `id="pppoe"`.  
Update the speed, name, features list and price on each `.pppoe-card`.  
Prices currently start from **Ksh 1,500** (5 Mbps) up to **Ksh 4,000** (50 Mbps). Adjust freely.

### Chatbot replies
In `script.js` edit the `botReplies` object.  
Add new keywords in the `respondToText()` function if needed.

### Colours & branding
In `styles.css` at the top (`:root`):
```css
--primary: #0B6E4F;
--accent: #F4A261;
```
Change these to match your preferred brand colours.

## How to open / test

1. Open `index.html` directly in a browser, **or**
2. Serve the folder with any static server, e.g.:
   ```bash
   npx serve .
   # or
   python -m http.server 8080
   ```

## Contact form behaviour

The form builds a `mailto:` link to `netanywhere254@gmail.com` so inquiries can be sent without a backend.  
For production you can replace this with:
- Formspree / Getform / Basin
- Your own PHP / Node endpoint
- WhatsApp deep link with pre-filled message

## M-PESA / STK Push

The payment modal is a **demo**.  
Connect your real payment provider (e.g. Safaricom Daraja, Kopokopo, or your ISP billing platform) in the `payNowBtn` click handler in `script.js`.

## Features included

- Responsive design (mobile + desktop)
- Hotspot voucher packages
- PPPoE Home Unlimited packages (5–50 Mbps)
- Free 30-min trial modal
- Refer & Earn modal
- Smart package recommendation tool
- Contact / query form with email support
- Integrated chatbot with quick replies
- Sticky header + mobile menu
- Clean, commented code ready for further editing
